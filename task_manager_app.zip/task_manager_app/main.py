from task_manager_app.task import Task
from task_manager_app.file_handler import load_tasks, save_tasks
from task_manager_app.input_validator import (
    validate_string_input,
    validate_priority,
    validate_numeric_input
)


def display_tasks(tasks):
    if not tasks:
        print("\nNo tasks found.\n")
        return

    print("\n------ Your Current Tasks ------")
    for i, task in enumerate(tasks, start=1):
        print(f"{i}. {task}")
    print("-------------------------------\n")


def add_task():
    print("\n=== Add New Task ===")

    name = validate_string_input("Enter task name: ")
    description = validate_string_input("Enter description: ")
    priority = validate_priority()

    task = Task(name, description, priority)

    tasks = load_tasks()
    tasks.append(task)
    save_tasks(tasks)

    print(f"Task '{name}' added successfully!\n")


def update_task():
    tasks = load_tasks()
    display_tasks(tasks)

    if not tasks:
        return

    index = validate_numeric_input("Enter task number to update: ") - 1

    if index < 0 or index >= len(tasks):
        print("Invalid task number.")
        return

    task = tasks[index]

    print("\nLeave field blank to keep existing value.")

    new_name = input(f"New name ({task.name}): ").strip()
    new_desc = input(f"New description ({task.description}): ").strip()
    new_priority = input(f"New priority ({task.priority}): ").strip()

    if new_name:
        task.name = new_name
    if new_desc:
        task.description = new_desc
    if new_priority:
        if new_priority.lower() in ["high", "medium", "low"]:
            task.priority = new_priority.capitalize()
        else:
            print("Invalid priority. Keeping old value.")

    save_tasks(tasks)
    print("Task updated successfully!\n")


def delete_task():
    tasks = load_tasks()
    display_tasks(tasks)

    if not tasks:
        return

    index = validate_numeric_input("Enter task number to delete: ") - 1

    if index < 0 or index >= len(tasks):
        print("Invalid task number.")
        return

    confirm = input("Are you sure? (y/n): ").strip().lower()

    if confirm == "y":
        removed = tasks.pop(index)
        save_tasks(tasks)
        print(f"Task '{removed.name}' deleted successfully!\n")
    else:
        print("Deletion cancelled.\n")


def main():
    while True:
        print("""
===== Task Manager Application =====
1. Add Task
2. View Tasks
3. Update Task
4. Delete Task
5. Exit
""")

        choice = input("Enter your choice: ").strip()

        if choice == "1":
            add_task()
        elif choice == "2":
            display_tasks(load_tasks())
        elif choice == "3":
            update_task()
        elif choice == "4":
            delete_task()
        elif choice == "5":
            print("Exiting Task Manager. Goodbye!")
            break
        else:
            print("Invalid choice. Try again.\n")


if __name__ == "__main__":
    main()
