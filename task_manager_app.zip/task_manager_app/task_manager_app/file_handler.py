import json
import os
from .task import Task


DATA_PATH = os.path.join("data", "tasks.json")


def load_tasks():
    if not os.path.exists(DATA_PATH):
        return []

    try:
        with open(DATA_PATH, "r") as f:
            data = json.load(f)
            return [Task.from_dict(item) for item in data]

    except json.JSONDecodeError:
        print("⚠ Warning: tasks.json is corrupted. Resetting file.")
        save_tasks([])
        return []


def save_tasks(tasks):
    with open(DATA_PATH, "w") as f:
        json.dump([task.to_dict() for task in tasks], f, indent=4)
