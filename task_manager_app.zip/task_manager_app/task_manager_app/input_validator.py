import re


def validate_string_input(prompt, pattern=None):
    while True:
        value = input(prompt).strip()

        if value == "":
            print("Input cannot be empty. Try again.")
            continue

        if pattern and not re.match(pattern, value):
            print("Invalid format. Try again.")
            continue

        return value


def validate_priority():
    allowed = ["high", "medium", "low"]

    while True:
        value = input("Enter priority (High/Medium/Low): ").strip().lower()

        if value in allowed:
            return value.capitalize()

        print("Invalid priority. Allowed: High, Medium, Low.")


def validate_numeric_input(prompt):
    while True:
        value = input(prompt).strip()

        if not value.isdigit():
            print("Please enter a valid positive number.")
            continue

        return int(value)
